var myMD = require('../models/spModel')
var fs = require('fs'); // thư viện xử lý về file

exports.DanhSach = async (req, res, next) => {
    // cải tiến thêm điều kiện lọc
    let dk = null;
    if (typeof (req.query.price) != 'undefined') {
        dk = { price: req.query.price } // lọc chính xác

        //lấy các sp giá lớn hơn hoặc bằng giá đã nhập
        // dk = { price: {$gte: req.query.price}}

    }

    let list = await myMD.spModel.find(dk).sort({ name: 1 });

    res.render('product/danh-sach', { listSP: list });
}

exports.XemChiTiet = async (req, res, next) => {
    let objSP = null;
    let msg = '';
    try {
        let id = req.params.id;

        objSP = await myMD.spModel.findOne({ _id: id });

        // xuống đến dòng này là không có lỗi
        msg = 'Lấy dữ liệu thành công';

    } catch (error) {
        msg = error.message;
    }
    res.render('product/chi-tiet', { objSP: objSP, msg: msg });
}

exports.Them = async (req, res, next) => {
    let msg = '';
    try {

 

        if (req.method == 'POST') {

            //1. Lấy dữ liệu từ form gửi lên
            let { name, price } = req.body;

            // có thể kiểm tra hợp liệu ở đây hoặc sau này cho vào middleware cài ở router
            //vd kiểm tra:
            if(name.length <3) 
            {
                msg = 'Cần nhập tên SP ít nhất 3 ký tự';
                return res.render('product/them', {msg: msg}); // chú ý: phải có chữ return
                // các trường dữ liệu khác làm tương tự
            }

            
            // Tạo đối tượng để ghi vào CSDL
            let objSP = new myMD.spModel();
            objSP.name = name;
            objSP.price = price;

             // trước khi ghi vào CSDL sẽ xử lý upload file ở đây
            
             if(fs.existsSync(req.file.path)){
                let file_path = './public/uploads/' + req.file.originalname; 

                // có tồn tại file
                // có thể kiểm tra định dạng file ....
                console.log(req.file);
                // { kết quả log có các thuộc tính, bạn muốn kiểm tra gì thì req.file.xxxxx
                //     fieldname: 'anh',
                //     originalname: 'giao-dien-mua-hang.png',
                //     encoding: '7bit',
                //     mimetype: 'image/png',
                //     destination: './tmp',
                //     filename: '280990afd14931ba2d750ff76630544e',
                //     path: 'tmp/280990afd14931ba2d750ff76630544e',
                //     size: 676236
                //   }
                if(req.file.mimetype.indexOf('image') ==-1){
                    // định dạng file chuẩn ảnh
                    msg = 'Không đúng định dạng ảnh';
                    return res.render('product/them', {msg: msg});// thoát khỏi hàm
                    // không ghi vào CSDL
                }
                // đến đây là phù hợp điều kiện
                fs.renameSync(req.file.path, file_path);

                // không có lỗi thì sẽ chạy xuống lệnh dưới đây
                objSP.image = '/uploads/' + req.file.originalname; 

             } 
 
            // Ghi vào CSDL
            let kq = await objSP.save();
            msg = 'Thêm thành công, id mới = '+ kq._id;
        }

    } catch (err) {
        msg = err.message;
    }

    res.render('product/them', {msg: msg});
}



exports.Sua = async (req, res, next) => {
    let msg = '';
    let objSP = null;

    try {
        // lấy thông tin sản phẩm: Copy ở chức năng xem chi tiết
        let id = req.params.id;
        objSP = await myMD.spModel.findOne({ _id: id });
        msg = 'Lấy dữ liệu thành công';

        //kiểm tra sự kiện post ở đây
        if (req.method == 'POST') {

            //1. Lấy dữ liệu từ form gửi lên
            let { name, price } = req.body;

            // có thể kiểm tra hợp liệu ở đây hoặc sau này cho vào middleware cài ở router
            //vd kiểm tra:
            if(name.length <3) 
            {
                msg = 'Cần nhập tên SP ít nhất 3 ký tự';
                return res.render('product/sua', {msg: msg, objSP:objSP});
                 // chú ý: phải có chữ return
                // các trường dữ liệu khác làm tương tự
            }
            
            // Tạo đối tượng để ghi vào CSDL
            let objSP_new = {}; // tạo đối tượng thường, không phải model
            objSP_new.name = name;
            objSP_new.price = price;
            // Ghi vào CSDL
            await myMD.spModel.findByIdAndUpdate(req.params.id, objSP_new);
            msg = 'Cập nhật thành công. ' 
        }





 
    } catch (err) {
        msg = err.message;
    }

    res.render('product/sua', {msg: msg, objSP:objSP});
}